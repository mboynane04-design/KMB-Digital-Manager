package com.kmbdigital.manager;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.*;
import java.util.Calendar;

public class MainActivity extends Activity {
    WebView web;
    static final int REQ=77;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient()); web.addJavascriptInterface(new KmbBridge(this, web), "Android");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ);
        scheduleDaily();
    }
    void scheduleDaily(){ AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE); Intent i=new Intent(this,ReminderReceiver.class); PendingIntent pi=PendingIntent.getBroadcast(this,1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar c=Calendar.getInstance(); c.set(Calendar.HOUR_OF_DAY,9); c.set(Calendar.MINUTE,0); c.set(Calendar.SECOND,0); if(c.getTimeInMillis()<=System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR,1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi); }
}

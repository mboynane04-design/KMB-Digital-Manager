package com.kmbdigital.manager;
import android.app.*; import android.content.*; import android.os.*; import org.json.*; import java.text.*; import java.util.*;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  String json=c.getSharedPreferences("kmb",0).getString("clients","[]");
  try{ JSONArray a=new JSONArray(json); SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US); long now=System.currentTimeMillis(); int count=0; StringBuilder names=new StringBuilder();
   for(int n=0;n<a.length();n++){ JSONObject o=a.getJSONObject(n); Date d=f.parse(o.getString("end")); long days=(d.getTime()-now)/(86400000L); if(days>=2 && days<=3){count++; if(names.length()>0)names.append(", "); names.append(o.getString("name"));}}
   if(count>0){ String ch="kmb_reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"KMB Digital rappels",NotificationManager.IMPORTANCE_DEFAULT));
    Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c); b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("KMB Digital — rappel").setContentText(names+" : abonnement(s) arrivent à expiration dans 3 jours.").setAutoCancel(true); nm.notify(1001,b.build()); }
  }catch(Exception e){}
 }
}

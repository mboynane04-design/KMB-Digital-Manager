package com.kmbdigital.manager;
import android.content.*; import android.webkit.*;
public class KmbBridge { final Context c; final WebView w; KmbBridge(Context c,WebView w){this.c=c;this.w=w;}
 @JavascriptInterface public void saveClients(String json){ c.getSharedPreferences("kmb",0).edit().putString("clients",json).apply(); }
}

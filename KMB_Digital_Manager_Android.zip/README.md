# KMB Digital Manager Android
Projet Android prêt à compiler. L'application embarque la version KMB Digital Manager dans une WebView, conserve les clients localement et synchronise les données vers Android pour les rappels quotidiens.
